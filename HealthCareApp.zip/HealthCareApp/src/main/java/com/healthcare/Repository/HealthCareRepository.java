package com.healthcare.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.Model.HealthCare;

public interface HealthCareRepository extends JpaRepository<HealthCare,Long> {

}
