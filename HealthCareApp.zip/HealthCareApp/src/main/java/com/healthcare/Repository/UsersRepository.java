package com.healthcare.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.Model.Users;

public interface UsersRepository extends JpaRepository <Users,Long> {

}
