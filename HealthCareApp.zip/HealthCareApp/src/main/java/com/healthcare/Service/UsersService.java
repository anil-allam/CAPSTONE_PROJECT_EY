package com.healthcare.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.healthcare.Model.Users;
import com.healthcare.Repository.UsersRepository;


@Service
public class UsersService {
	
	@Autowired
	private UsersRepository users;
	
	public List<Users> getAll(){
		return users.findAll();
	}
	
	
	public Users save(Users user) {
		return users.save(user);
	}
	
	public void deleteById(Long id) {
		users.deleteById(id);
	}
	
	public void saveOrUpdate(Users user) {
		users.save(user);
	}
	

}
