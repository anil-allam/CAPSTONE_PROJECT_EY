package com.healthcare.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.Model.HealthCare;
import com.healthcare.Service.HealthCareService;



@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/health")
public class HealthCareController {
	
	
	@Autowired
	private HealthCareService careService;
	
	@PostMapping("/savemedicine")
	HealthCare newMedicine(@RequestBody HealthCare newMedicine) {
		return careService.save(newMedicine);
	}
	
	@GetMapping("/getAll")
	List<HealthCare> getAllList(){
		return careService.getAll();
	}
	
	@DeleteMapping("/deletemedicine/{id}") 
	void deleteMedicine(@PathVariable Long id) {
		
		careService.deletebyId(id);
	}
	
	@PutMapping("/updatemedicine/{id}")
	public HealthCare Update(@RequestBody HealthCare medicine) {
		careService.saveorUpdate(medicine);
		return medicine;
		
	}

}
